
const reveals = document.querySelectorAll('.reveal');

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry, index) => {
    if (entry.isIntersecting) {
      // Atraso escalonado para cada elemento (efeito cascata)
      setTimeout(() => {
        entry.target.classList.add('visible');
      }, index * 60);
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

reveals.forEach(el => observer.observe(el));


const form = document.querySelector('.contato-form');
const btnEnviar = document.getElementById('btn-enviar');

btnEnviar.addEventListener('click', function () {
  const nome = document.getElementById('campo-nome').value.trim();
  const email = document.getElementById('campo-email').value.trim();
  const assunto = document.getElementById('campo-assunto').value.trim();
  const mensagem = document.getElementById('campo-mensagem').value.trim();

 
  if (!nome || !email || !assunto || !mensagem) {
    alert('⚠️ Por favor, preencha todos os campos antes de enviar.');
    return;
  }

 
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert('⚠️ Por favor, insira um e-mail válido.');
    return;
  }

  
  btnEnviar.textContent = 'Enviando...';
  btnEnviar.disabled = true;

  setTimeout(() => {
    alert('✅ Mensagem enviada com sucesso! Em breve entraremos em contato.');
    document.getElementById('campo-nome').value = '';
    document.getElementById('campo-email').value = '';
    document.getElementById('campo-assunto').value = '';
    document.getElementById('campo-mensagem').value = '';
    btnEnviar.textContent = 'Enviar Mensagem';
    btnEnviar.disabled = false;
  }, 1000);
});



const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-links a');

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      navLinks.forEach(link => link.classList.remove('ativo'));
      const link = document.querySelector(`.nav-links a[href="#${entry.target.id}"]`);
      if (link) link.classList.add('ativo');
    }
  });
}, { threshold: 0.4 });

sections.forEach(sec => sectionObserver.observe(sec));



function animarContador(elemento, destino, sufixo = '', duracao = 1500) {
  let inicio = 0;
  const passo = destino / (duracao / 16);

  const timer = setInterval(() => {
    inicio += passo;
    if (inicio >= destino) {
      elemento.textContent = destino + sufixo;
      clearInterval(timer);
    } else {
      elemento.textContent = Math.floor(inicio) + sufixo;
    }
  }, 16);
}

const statsObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const numeros = entry.target.querySelectorAll('.stat-num');
      numeros.forEach(num => {
        const texto = num.getAttribute('data-valor');
        const sufixo = num.getAttribute('data-sufixo') || '';
        animarContador(num, parseInt(texto), sufixo);
      });
      statsObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.5 });

const statsSection = document.querySelector('.stats');
if (statsSection) statsSection && statsObserver.observe(statsSection);
